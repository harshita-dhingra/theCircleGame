const CONSTANT = {
  COUNT: 3,

};

export { CONSTANT };